import UIKit

var greeting = "Hello, playground"
// 22222
var qq: Int = 10
var ww: Double = 2.499749899
var ee: Float = 2.3953
var darktheme: Bool = false
var whitetheme: Bool = true
var str: String = ("Добрый вечер")

let rr: Int = 10
let tt: Double = 2.499749899
let yy: Float = 2.3953
let darktheme1: Bool = false
let whitetheme1: Bool = true
let str1: String = ("Добрый вечер")

print(Int.max)
print(Int.min)

// 333333
let a: Int = 10
let b: Double = 2.15

var sum: Double = b + Double(a)

var c: Int = 14000
let d: Double = 5000

var sum2: Int = c + Int(d)

var e: Double = 15.56
var f: Float = 16.76

var sum3: Float = Float(e) + f

var g: Double = 65.90
var h: Double = 75.10

let sum4: Int = Int(g) + Int(h)

var j: Int = 15
var k: Int = 16
var sum5: Double = Double(j) + Double(k)

var l: Float = 2.67
var z: Int = 15

var sum6: Float = l + Float(z)

let p: Int = 9999
let m: Float = 9999

let sum7: Int = p + Int(m)

let b1: Double = 15
let b2: Int = 32

let sum8: Int = b2 + Int(b1)
//444444

var w1: Int = 5
var w2: Int = 5

var suma1: Int = w1 + w2
print("5 + 5 =", suma1)

var e1: Int = 76
var e2: Int = 45

var suma2: Int = e1 - e2
print("76 + 45 =", suma2)

var t1: Int = 15
var t2: Int = 3

var suma3: Int = t1 / t2
print("15 + 3 =", suma3)

var y1: Int = 12
var y2: Int = 6

var suma4: Int = y1 * y2
print("12 + 6 =", suma3)

//555555

var isnight: Bool = true
print(isnight)

//6666666

var stroka = "potato"
for potato in stroka {
    print(potato) 
}
//777777

let lok = 13 % 2
let lak = 2 % 2
let lik = 20 % 2
let ltk = 21 % 2
let lyk = 76 % 2

//10000

for index in 2...9 {
    for index1 in 2...9{
        print("\(index) * \(index1) = \(index * index1)")
    }
}

//888888

let day: Int = 16
